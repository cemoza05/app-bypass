import os
import platform

def clear_screen():
    if platform.system() == "Windows":
        os.system("cls")
    else:
        os.system("clear")

banner = """
/_ Batosay1337 Projects ___       /
                   Telegram @Batosay1337_#
"""

def main():
    clear_screen()
    print(banner)
    print("Pilih file yang ingin dijalankan:")
    print("01 - Reverse IP")
    print("02 - Grabber Domain")
    print("03 - Domain To IP")
    print("04 - RCE Finder Auto Install GS")
    print("05 - Subdomain Finder [Coming Soon]")

    choice = input("root@batosay1337:~# ").strip()

    # Normalize choice by stripping leading zeros
    normalized_choice = choice.lstrip('0') or '0'

    clear_screen()  # Clear the screen before running the selected script

    if normalized_choice == "1":
        os.system("python files/rev.py")
    elif normalized_choice == "2":
        os.system("python files/grab.py")
    elif normalized_choice == "3":
        os.system("python files/domip.py")
    elif normalized_choice == "4":
        os.system("python files/rce.py")
    elif normalized_choice == "5":
        print("Subdomain Finder belum tersedia.")
    else:
        print("Pilihan tidak valid. Silakan coba lagi.")

if __name__ == "__main__":
    main()
