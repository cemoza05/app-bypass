import asyncio
from playwright.async_api import async_playwright

chrome_path = "C:/Program Files/Google/Chrome/Application/chrome.exe"

banner = """
/_ Batosay1337 Projects ___       /
                   Grabber Domain_#
"""

async def grab_domains(tahun, bulan):
    file_name = f"Result-{tahun}-{bulan}.txt"
    
    async with async_playwright() as p:
        browser = await p.chromium.launch(
            headless=False,  
            executable_path=chrome_path
        )
        context = await browser.new_context()
        page = await context.new_page()
        
        with open(file_name, 'w') as file:
            for tanggal in range(1, 35):  
                formatted_tanggal = f"{tanggal:02d}"  
                
                for page_num in range(1, 51):  
                    url = f"https://www.cubdomain.com/domains-registered-by-date/{tahun}-{bulan}-{formatted_tanggal}/{page_num}"
                    
                    try:
                        await page.goto(url)
                        
                        consent_button = await page.query_selector('button.fc-button.fc-cta-consent.fc-primary-button')
                        
                        if consent_button:
                            await consent_button.click()
                            print("Tombol 'Consent' diklik.")
                        
                        await page.wait_for_selector("div.col-md-4.mb-1.mb-md-0", timeout=60000)
                        
                        domain_elements = await page.query_selector_all("div.col-md-4.mb-1.mb-md-0 a")
                        domains = [await element.text_content() for element in domain_elements]
                        
                        for domain in domains:
                            file.write(f"{domain}\n")
                        
                        print(f"Batosay1337 Project {tahun}-{bulan}-{formatted_tanggal} {len(domains)} Domain Grabbed Page {page_num}")
                    except Exception as e:
                        print(f"Gagal mengakses halaman {url}: {e}")

        await browser.close()
    
    print(f"Hasil telah disimpan di {file_name}")

if __name__ == "__main__":
    print(banner)
    tahun = input("Masukkan tahun (contoh: 2024): ")
    bulan = input("Masukkan bulan (contoh: 08): ")

    asyncio.run(grab_domains(tahun, bulan))
